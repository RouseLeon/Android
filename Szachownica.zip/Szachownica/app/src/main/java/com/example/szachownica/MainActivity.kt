package com.example.szachownica

import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.szachownica.ui.theme.Panel

class MainActivity : ComponentActivity() {

    private lateinit var panel: Panel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        panel = Panel(this)
        setContentView(panel)

        registerForContextMenu(panel)
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        menu.setHeaderTitle("Ustawienia szachownicy")
        menu.add(0, MENU_CZARNA, 0, "Czarne pola")
        menu.add(0, MENU_BIALA, 1, "Białe pola")
        menu.add(0, MENU_RESET, 2, "Przywróć domyślne kolory")
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            MENU_CZARNA -> {
                Toast.makeText(this, "Wybrano czarne pola", Toast.LENGTH_SHORT).show()
                true
            }

            MENU_BIALA -> {
                Toast.makeText(this, "Wybrano białe pola", Toast.LENGTH_SHORT).show()
                true
            }

            MENU_RESET -> {
                Toast.makeText(this, "Przywrócono domyślne kolory", Toast.LENGTH_SHORT).show()
                true
            }

            else -> super.onContextItemSelected(item)
        }
    }

    companion object {
        private const val MENU_CZARNA = 1
        private const val MENU_BIALA = 2
        private const val MENU_RESET = 3
    }
}