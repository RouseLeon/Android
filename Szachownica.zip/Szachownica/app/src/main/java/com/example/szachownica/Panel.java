package com.example.szachownica;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;


public class Panel extends View {

    public static Paint tlo_pola = new Paint();
    public static Paint tlo_pola2 = new Paint();

    public Panel(Context context) {
        super(context);
        init();
    }

    public Panel(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        tlo_pola.setColor(Color.WHITE);
        tlo_pola2.setColor(Color.BLACK);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.GRAY);

        float size = Math.min(getWidth(), getHeight());
        float squareSize = size / 8f;
        float offsetX = (getWidth() - size) / 2f;
        float offsetY = (getHeight() - size) / 2f;

        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                float left = offsetX + x * squareSize;
                float top = offsetY + y * squareSize;
                float right = offsetX + (x + 1) * squareSize;
                float bottom = offsetY + (y + 1) * squareSize;

                if ((x + y) % 2 == 0) {
                    canvas.drawRect(left, top, right, bottom, tlo_pola);
                } else {
                    canvas.drawRect(left, top, right, bottom, tlo_pola2);
                }
            }
        }
    }
}

