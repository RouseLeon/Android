
package com.example.szachownica.ui.theme

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.min

class Panel(context: Context) : View(context) {

    private val lightPole = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val darkPole = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width.toFloat()
        val height = height.toFloat()

        val rozmiar = min(width, height)
        val rozmiarPola = rozmiar / 8f

        val lewy = (width - rozmiar) / 2f
        val gora = (height - rozmiar) / 2f

        for (wiersz in 0 until 8) {
            for (kolumna in 0 until 8) {

                val x1 = lewy + kolumna * rozmiarPola
                val y1 = gora + wiersz * rozmiarPola
                val x2 = x1 + rozmiarPola
                val y2 = y1 + rozmiarPola

                val kolor = if ((wiersz + kolumna) % 2 == 0) {
                    lightPole
                } else {
                    darkPole
                }

                canvas.drawRect(x1, y1, x2, y2, kolor)
            }
        }
    }
}
