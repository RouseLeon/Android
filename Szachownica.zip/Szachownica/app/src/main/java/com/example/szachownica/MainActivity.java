package com.example.szachownica;

import android.os.Bundle;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.provider.Settings;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Panel panel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        panel = findViewById(R.id.panel);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.autor) {
            Toast toast = Toast.makeText(getApplicationContext(), "Twórca: Paweł Solovei", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.BOTTOM, 0, 0);
            toast.show();
            return true;
        } else if (id == R.id.wyjscie) {
            finish();
            return true;
        } else if (id == R.id.kolor1) {
            Panel.tlo_pola.setColor(Color.WHITE);
            Panel.tlo_pola2.setColor(Color.BLACK);
            if (panel != null) {
                panel.invalidate();
            }
            return true;
        } else if (id == R.id.kolor2) {
            Panel.tlo_pola.setColor(Color.BLUE);
            Panel.tlo_pola2.setColor(Color.RED);
            if (panel != null) {
                panel.invalidate();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}