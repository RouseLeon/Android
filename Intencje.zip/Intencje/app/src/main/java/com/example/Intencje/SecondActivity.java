package com.example.Intencje;


import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.Intencje.R;

public class SecondActivity extends AppCompatActivity {

    private TextView txtStudentInfo, txtBackInstructionMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtStudentInfo = findViewById(R.id.txtStudentDetails);
        txtBackInstructionMsg = findViewById(R.id.txtBackInstruction);

        txtStudentInfo.setText("Pavlo Solovei");
        txtBackInstructionMsg.setText("Kliknij przycisk powrót by wrócić do poprzedniego ekranu");
    }
}