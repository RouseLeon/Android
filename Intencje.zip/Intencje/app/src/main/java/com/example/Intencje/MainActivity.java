package com.example.Intencje;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.Intencje.SecondActivity;
import com.example.Intencje.R;

public class MainActivity extends AppCompatActivity {

    private Button btnOpenPersonalAct, btnOpenWebAddress, btnOpenGpsAct;
    private EditText inputUrlAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOpenPersonalAct = findViewById(R.id.btnImieNazwisko);
        btnOpenWebAddress = findViewById(R.id.btnAdres);
        btnOpenGpsAct = findViewById(R.id.btnGeo);
        inputUrlAddress = findViewById(R.id.tvURL);

        btnOpenPersonalAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent explicitIntent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(explicitIntent);
            }
        });

        btnOpenWebAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String targetUrl = inputUrlAddress.getText().toString().trim();

                if (!targetUrl.isEmpty()) {
                    if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
                        targetUrl = "http://" + targetUrl;
                    }
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl));
                    startActivity(browserIntent);
                } else {
                    Toast.makeText(MainActivity.this, "Wprowadź poprawny URL", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnOpenGpsAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gpsIntent = new Intent(MainActivity.this, ThirdActivity.class);
                startActivity(gpsIntent);
            }
        });
    }
}