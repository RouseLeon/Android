package com.example.Intencje;


import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.Intencje.R;

public class ThirdActivity extends AppCompatActivity {

    private Button btnStartGps, btnStopGps;
    private TextView txtLatitude, txtLongitude;

    public LocationManager locManager;
    private LocationListener locListener;

    private static final int PERMISSION_REQUEST_GPS = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        btnStartGps = findViewById(R.id.btnStart);
        btnStopGps = findViewById(R.id.btnStop);
        txtLatitude = findViewById(R.id.tvSzer);
        txtLongitude = findViewById(R.id.tvDlug);

        btnStartGps.setEnabled(true);
        btnStopGps.setEnabled(false);

        locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        locListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                String latitudeVal = String.valueOf(location.getLatitude());
                String longitudeVal = String.valueOf(location.getLongitude());

                txtLatitude.setText(latitudeVal);
                txtLongitude.setText(longitudeVal);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            @Override
            public void onProviderEnabled(@NonNull String provider) {}

            @Override
            public void onProviderDisabled(@NonNull String provider) {}
        };

        btnStartGps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enableLocationTracking();
            }
        });

        btnStopGps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disableLocationTracking();
            }
        });
    }

    private void enableLocationTracking() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    PERMISSION_REQUEST_GPS
            );
            return;
        }

        locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locListener);

        btnStartGps.setEnabled(false);
        btnStopGps.setEnabled(true);
        Toast.makeText(this, "Pobieranie pozycji uruchomione", Toast.LENGTH_SHORT).show();
    }

    private void disableLocationTracking() {
        if (locManager != null && locListener != null) {
            locManager.removeUpdates(locListener);
        }

        btnStartGps.setEnabled(true);
        btnStopGps.setEnabled(false);
        Toast.makeText(this, "Pobieranie pozycji zatrzymane", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_GPS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableLocationTracking();
            } else {
                Toast.makeText(this, "Brak wymaganych uprawnień GPS", Toast.LENGTH_SHORT).show();
            }
        }
    }
}